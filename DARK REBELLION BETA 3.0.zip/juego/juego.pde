ArrayList<Plataforma> listaPlataformas = new ArrayList<Plataforma>();
ArrayList<Enemigo> listaEnemigos = new ArrayList<Enemigo>();
ArrayList<Moneda> listaMonedas = new ArrayList<Moneda>();

float proximaPlataformaX = 400;
Jugador heroe;

// Texturas precargadas globales para optimizar rendimiento
PImage imgJugadorIdle, imgJugadorJump, imgJugadorRun, imgJugadorAttack;
PImage imgEneFuego, imgEneFantasma;
PImage imgMoneda;
PImage imgMenu, imgMascara;

float gravedad = 0.4;
float camaraX = 0;
float anchoSuelo = 400;
float anchoNubeBucle = 300;

int estado = 0, monedasRecolectadas = 0;

PFont fuenteTitulo;

void setup() {
  size(800, 600);

  // 1. Precarga de assets del Jugador
  imgJugadorIdle   = loadImage("centinela.png");
  imgJugadorJump   = loadImage("centinela_saltando.png");
  imgJugadorRun    = loadImage("centinela_corriendo.png");
  imgJugadorAttack = loadImage("golpe.png"); 

  // 2. Precarga de assets de Enemigos y objetos (Se removieron las referencias al disparador)
  imgEneFuego    = loadImage("fantasma de fuego.png");
  imgEneFantasma = loadImage("fantasma.png");
  imgMoneda      = loadImage("puntos reales.png");

  // 3. Menu y HUD
  imgMenu = loadImage("menu.png");
  imgMenu.resize(0, height);
  imgMenu = imgMenu.get((imgMenu.width - width) / 2, 0, width, height);

  imgMascara = loadImage("mascara.png");
  imgMascara.resize(26, 0);

  fuenteTitulo = createFont("Impact", 64);

  reiniciarJuego();
  estado = 0; // Iniciar en el menú principal
}

void draw() {
  switch (estado) {
    case 0:
      dibujarMenuInicio();
      break;
    case 1:
      background(135, 206, 235); 
      dibujarJuego();
      break;
    case 2:
      background(135, 206, 235);
      dibujarJuego(); // Muestra el juego congelado detrás de la pantalla de Game Over
      break;
    case 3:
      dibujarPantallaAyuda();
      break;
  }
}

void reiniciarJuego() {
  listaPlataformas.clear();
  listaEnemigos.clear();
  listaMonedas.clear();

  monedasRecolectadas = 0;
  camaraX = 0;
  proximaPlataformaX = 400;

  // Constructor actualizado con la imagen de ataque
  heroe = new Jugador(100, 300, imgJugadorIdle, imgJugadorJump, imgJugadorRun, imgJugadorAttack);

  crearNuevaPlataforma();
  crearNuevaPlataforma();
  crearNuevaPlataforma();

  estado = 1;
}

void dibujarMenuInicio() {
  image(imgMenu, 0, 0);
  strokeWeight(2);

  // TÍTULO CON EFECTO DE DESVANECIMIENTO CONTINUO Y RESPLANDOR ROJO (GLOW)
  textAlign(CENTER, CENTER);
  textFont(fuenteTitulo);
  
  float opacidadBase = map(sin(frameCount * 0.05), -1, 1, 60, 255);
  float tituloX = width / 2;
  float tituloY = height / 4;


  int radioResplandor = 6; 
  for (int i = 1; i <= radioResplandor; i++) {
    float opacidadBrillo = map(i, 1, radioResplandor, opacidadBase * 0.4, 2);
    fill(200, 0, 0, opacidadBrillo);
    text("DARK REBELLION", tituloX - i, tituloY);
    text("DARK REBELLION", tituloX + i, tituloY);
    text("DARK REBELLION", tituloX, tituloY - i);
    text("DARK REBELLION", tituloX, tituloY + i);
    text("DARK REBELLION", tituloX - i, tituloY - i);
    text("DARK REBELLION", tituloX + i, tituloY + i);
  }
  
  fill(130, 0, 0, opacidadBase); 
  text("DARK REBELLION", tituloX, tituloY);

  // CONFIGURACIÓN DE LOS BOTONES ESTILO MEDIEVAL INTERACTIVOS
  float botonAncho = 260;
  float botonAlto = 55;
  float centroX = width / 2;
  
  float btnJugarX = centroX - (botonAncho / 2);
  float btnJugarY = (height / 2) - 10;
  
  float btnAyudaX = centroX - (botonAncho / 2);
  float btnAyudaY = (height / 2) + 70;

  dibujarBotonMedieval(btnJugarX, btnJugarY, botonAncho, botonAlto, "ENTER PARA EMPEZAR");
  dibujarBotonMedieval(btnAyudaX, btnAyudaY, botonAncho, botonAlto, "AYUDA / CONTROLES");
  
  textAlign(LEFT, BASELINE);
}

void dibujarBotonMedieval(float x, float y, float ancho, float alto, String texto) {
  boolean mouseEncima = (mouseX > x && mouseX < x + ancho && mouseY > y && mouseY < y + alto);
  pushStyle();
  rectMode(CORNER);
  
  if (mouseEncima) {
    noFill();
    for (int i = 1; i <= 8; i++) {
      stroke(180, 0, 0, map(i, 1, 8, 45, 2));
      strokeWeight(i * 2);
      rect(x - i, y - i, ancho + (i * 2), alto + (i * 2), 8);
    }
  }
  
  if (mouseEncima) {
    fill(40, 10, 10, 230);    
    stroke(180, 0, 0);         
    strokeWeight(2.5);
  } else {
    fill(20, 20, 20, 210);    
    stroke(120, 100, 70);     
    strokeWeight(2);
  }
  rect(x, y, ancho, alto, 4);

  if (mouseEncima) fill(220, 0, 0); else fill(160, 140, 110);
  noStroke();
  rect(x + 4, y + 4, 4, 4);
  rect(x + ancho - 8, y + 4, 4, 4);
  rect(x + 4, y + alto - 8, 4, 4);
  rect(x + ancho - 8, y + alto - 8, 4, 4);

  textAlign(CENTER, CENTER);
  if (mouseEncima) fill(255, 200, 200); else fill(210, 190, 160);
  textSize(14);
  text(texto, x + (ancho / 2), y + (alto / 2) - 2);
  popStyle();
}

void dibujarPantallaAyuda() {
  image(imgMenu, 0, 0);
  fill(0, 0, 0, 200);
  rect(0, 0, width, height);

  textAlign(CENTER, CENTER);
  fill(255, 215, 0);
  textSize(40);
  text("GUÍA DE CONTROLES", width / 2, height / 4 - 40);

  fill(20, 20, 20, 180);
  stroke(255, 100);
  rect(width / 2 - 250, height / 3 - 20, 500, 310, 15);

  fill(255); textSize(18); text("MOVIMIENTO", width / 2, height / 3 + 10);
  fill(200); textSize(15); text("Teclas 'A' / 'D'   o   Flechas Izquierda / Derecha", width / 2, height / 3 + 35);

  fill(255); textSize(18); text("SALTAR (CON DOBLE SALTO)", width / 2, height / 3 + 90);
  fill(200); textSize(15); text("Tecla 'W'   o   Flecha Arriba   o   Barra Espaciadora", width / 2, height / 3 + 115);

  fill(255); textSize(18); text("ATACAR (CUERPO A CUERPO)", width / 2, height / 3 + 170);
  fill(200); textSize(15); text("Tecla 'J'   o   Tecla 'Z'", width / 2, height / 3 + 195);

  float volverX = width / 2 - 80;
  float volverY = height / 3 + 310;
  float volverAncho = 160;
  float volverAlto = 45;

  if (mouseX > volverX && mouseX < volverX + volverAncho && mouseY > volverY && mouseY < volverY + volverAlto) {
    fill(80, 80, 80);
  } else {
    fill(40, 40, 40);
  }
  rect(volverX, volverY, volverAncho, volverAlto, 8);
  
  fill(255); textSize(16);
  text("VOLVER (ESC)", width / 2, volverY + (volverAlto / 2));
  textAlign(LEFT, BASELINE);
}

void dibujarNubesBucle(float camaraOffset) {
  int nubeInicio = floor(camaraOffset / anchoNubeBucle);
  int nubesVisibles = ceil(width / anchoNubeBucle) + 1;

  pushMatrix();
  translate(-camaraOffset, 0);
  fill(255, 255, 255, 200);
  noStroke();
  for (int i = nubeInicio; i <= nubeInicio + nubesVisibles; i++) {
    float nubeX = i * anchoNubeBucle;
    ellipse(nubeX + 50, 100, 60, 50);
    ellipse(nubeX + 80, 90, 80, 60);
    ellipse(nubeX + 110, 100, 60, 50);
    ellipse(nubeX + 200, 150, 70, 45);
    ellipse(nubeX + 230, 145, 90, 55);
  }
  popMatrix();
}

void dibujarJuego() {
  if (estado == 1) {
    heroe.actualizar(gravedad);
    if (heroe.pos.x > width / 2) camaraX = heroe.pos.x - width / 2;
    if (heroe.pos.y > height + 100) heroe.vidas = 0;
    if (heroe.vidas <= 0) estado = 2;
  } else {
    heroe.teclaIzquierda = false;
    heroe.teclaDerecha = false;
  }

  dibujarNubesBucle(camaraX * 0.3);
  stroke(0);
  heroe.enElSuelo = false;

  int bloqueInicio = floor(camaraX / anchoSuelo);
  int bloquesVisibles = ceil(width / anchoSuelo) + 1;

  pushMatrix();
  translate(-camaraX, 0);

  fill(34, 139, 34);
  for (int i = bloqueInicio; i <= bloqueInicio + bloquesVisibles; i++) {
    float sueloX = i * anchoSuelo;
    rect(sueloX, 500, anchoSuelo, 100);
    heroe.verificarColisionSuelo(sueloX, 500, anchoSuelo);
  }

  for (int i = listaPlataformas.size() - 1; i >= 0; i--) {
    Plataforma plat = listaPlataformas.get(i);
    plat.mostrar();
    heroe.verificarColisionSuelo(plat.pos.x, plat.pos.y, plat.ancho);
    if (estado == 1 && plat.pos.x < camaraX - 200) listaPlataformas.remove(i);
  }

  float heroeCentroX = heroe.pos.x + (heroe.ancho / 2);
  float heroeCentroY = heroe.pos.y + (heroe.alto / 2);

  for (int i = listaEnemigos.size() - 1; i >= 0; i--) {
    Enemigo ene = listaEnemigos.get(i);
    if (estado == 1) ene.actualizar();
    ene.dibujar();

    if (estado == 1) {
      // COLISIÓN CON ATAQUE DE ESPADA (SISTEMA MELEE)
      if (heroe.verificarImpactoEnemigo(ene.pos.x, ene.pos.y, ene.radio)) {
        listaEnemigos.remove(i);
        continue; 
      }

      float distancia = dist(heroeCentroX, heroeCentroY, ene.pos.x, ene.pos.y);
      if (distancia < ((heroe.ancho / 2) + ene.radio)) {
        if (heroe.vel.y > 0 && (heroe.pos.y + heroe.alto) < ene.pos.y + 10) {
          listaEnemigos.remove(i);
          heroe.vel.y = -9;
          heroe.enElSuelo = false;
        } else {
          heroe.recibirDano();
        }
      } else if (ene.pos.x < camaraX - 200) {
        listaEnemigos.remove(i);
      }
    }
  }

  for (int i = listaMonedas.size() - 1; i >= 0; i--) {
    Moneda m = listaMonedas.get(i);
    if (estado == 1) m.actualizar();
    m.dibujar();

    if (estado == 1) {
      if (dist(heroeCentroX, heroeCentroY, m.pos.x, m.pos.y) < ((heroe.ancho / 2) + m.radio)) {
        monedasRecolectadas++;
        listaMonedas.remove(i);
      } else if (m.pos.x < camaraX - 200) {
        listaMonedas.remove(i);
      }
    }
  }

  if (estado == 1 && proximaPlataformaX < camaraX + width + 400) crearNuevaPlataforma();

  heroe.dibujar();
  popMatrix();

  // HUD: MÁSCARAS HOLLOW KNIGHT
  pushStyle();
  imageMode(CENTER);
  for (int i = 0; i < heroe.vidas; i++) {
    float mascaraX = 35 + (i * 35);
    float mascaraY = 40;
    if (heroe.invencible && estado == 1) {
      mascaraX += random(-2, 2);
      mascaraY += random(-2, 2);
    }
    image(imgMascara, mascaraX, mascaraY);
  }
  popStyle();

  textAlign(RIGHT, BASELINE);
  textSize(24); fill(255, 215, 0); stroke(0); strokeWeight(4);
  text("MONEDAS: " + monedasRecolectadas, width - 20, 40);
  textAlign(LEFT, BASELINE);

if (estado == 2) {
fill(0, 0, 0, 180);
rect(0, 0, width, height);
fill(255, 50, 50); textSize(50); textAlign(CENTER, CENTER);
text("GAME OVER", width / 2, height / 2 - 20);
fill(255); textSize(20);
text("Presiona 'R' para volver a jugar", width / 2, height / 2 + 40);
textAlign(LEFT, BASELINE);
}
}
void crearNuevaPlataforma() {
float aleatorioY = random(300, 450);
Plataforma nuevaPlat = new Plataforma(proximaPlataformaX, aleatorioY);
listaPlataformas.add(nuevaPlat);
if (random(100) < 60) {
int cantidadMonedas = (int)random(2, 5);
float espacio = nuevaPlat.ancho / (cantidadMonedas + 1);
for (int i = 1; i <= cantidadMonedas; i++) {
listaMonedas.add(new Moneda(nuevaPlat.pos.x + (i * espacio), nuevaPlat.pos.y - 40, imgMoneda));
}
} else if (random(100) < 70) {
float tipoEnemigo = random(100);
if (tipoEnemigo < 50) {
listaEnemigos.add(new Enemigo(nuevaPlat, 20, imgEneFuego));
} else {
listaEnemigos.add(new EnemigoVolador(nuevaPlat, 20, imgEneFantasma));
}
}
proximaPlataformaX += nuevaPlat.ancho + random(100, 250);
}
void mousePressed() {
if (estado == 0) {
float botonAncho = 260; float botonAlto = 55; float centroX = width / 2;
float btnJugarX = centroX - (botonAncho / 2);
float btnJugarY = (height / 2) - 10;
float btnAyudaX = centroX - (botonAncho / 2);
float btnAyudaY = (height / 2) + 70;
if (mouseX > btnJugarX && mouseX < btnJugarX + botonAncho && mouseY > btnJugarY && mouseY < btnJugarY + botonAlto) {
reiniciarJuego();
}
if (mouseX > btnAyudaX && mouseX < btnAyudaX + botonAncho && mouseY > btnAyudaY && mouseY < btnAyudaY + botonAlto) {
estado = 3;
}
} else if (estado == 3) {
float volverX = width / 2 - 80; float volverY = height / 3 + 310;
float volverAncho = 160; float volverAlto = 45;
if (mouseX > volverX && mouseX < volverX + volverAncho && mouseY > volverY && mouseY < volverY + volverAlto) {
estado = 0;
}
}
}
