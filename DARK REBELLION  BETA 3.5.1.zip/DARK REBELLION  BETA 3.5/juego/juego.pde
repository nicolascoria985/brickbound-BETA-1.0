ArrayList<Plataforma> listaPlataformas = new ArrayList<Plataforma>();
ArrayList<Enemigo> listaEnemigos = new ArrayList<Enemigo>();
ArrayList<Moneda> listaMonedas = new ArrayList<Moneda>();

float proximaPlataformaX = 400;
Jugador heroe;
Sala sala;

// Texturas precargadas globales para optimizar rendimiento
PImage imgJugadorIdle, imgJugadorJump, imgJugadorRun, imgJugadorAttack, imgJugadorDash;
PImage imgEneFuego, imgEneFantasma;
PImage imgMoneda;
PImage imgMenu, imgMascara;

float gravedad = 0.4;
float camaraX = 0;
float anchoSuelo = 400;
float anchoNubeBucle = 300;

int estado = 0, monedasRecolectadas = 0;

PFont fuenteMedieval;

void setup() {
  size(800, 600);

  // 1. Precarga de assets del Jugador
  imgJugadorIdle = loadImage("centinela.png");
  imgJugadorJump = loadImage("centinela_saltando.png");
  imgJugadorRun = loadImage("centinela_corriendo.png");
  imgJugadorAttack = loadImage("golpe.png");
  imgJugadorDash = loadImage("dash.png");


  // 2. Precarga de assets de Enemigos y objetos
  imgEneFuego = loadImage("fantasma de fuego.png");
  imgEneFantasma = loadImage("fantasma.png");
  imgMoneda = loadImage("puntos reales.png");

  // 3. Menu y HUD
  imgMenu = loadImage("menu.png");
  imgMenu.resize(0, height);
  imgMenu = imgMenu.get((imgMenu.width - width) / 2, 0, width, height);

  imgMascara = loadImage("mascara.png");
  imgMascara.resize(26, 0);

  fuenteMedieval = createFont("CloisterBlack.ttf", 64);

  sala = new Sala("Nivel_01.tmx", "tileset_nivel01.png", height / 18.0);
  
  reiniciarJuego();
  estado = 0; // Iniciar en el menú principal
}

void draw() {
  switch (estado) {
  case 0:
    dibujarMenuInicio();
    break;
  case 1:
    background(135, 206, 235);
    dibujarJuego();
    break;
  case 2:
    background(135, 206, 235);
    dibujarJuego(); // Muestra el juego congelado detrás de la pantalla de Game Over
    break;
  case 3:
    dibujarPantallaAyuda();
    break;

  case 4:
    dibujarJuego();
    dibujarPantallaPausa();
    break;
  }
}

void reiniciarJuego() {
  listaPlataformas.clear();
  listaEnemigos.clear();
  listaMonedas.clear();

  monedasRecolectadas = 0;
  camaraX = 0;
  proximaPlataformaX = 400;

  // Constructor actualizado con la imagen de ataque
  heroe = new Jugador(100, 300, imgJugadorIdle, imgJugadorJump, imgJugadorRun, imgJugadorAttack, imgJugadorDash);

  crearNuevaPlataforma();
  crearNuevaPlataforma();
  crearNuevaPlataforma();

  estado = 1;
}

//cosas que se iran
void dibujarNubesBucle(float camaraOffset) {
  int nubeInicio = floor(camaraOffset / anchoNubeBucle);
  int nubesVisibles = ceil(width / anchoNubeBucle) + 1;

  pushMatrix();
  translate(-camaraOffset, 0);
  fill(255, 255, 255, 200);
  noStroke();
  for (int i = nubeInicio; i <= nubeInicio + nubesVisibles; i++) {
    float nubeX = i * anchoNubeBucle;
    ellipse(nubeX + 50, 100, 60, 50);
    ellipse(nubeX + 80, 90, 80, 60);
    ellipse(nubeX + 110, 100, 60, 50);
    ellipse(nubeX + 200, 150, 70, 45);
    ellipse(nubeX + 230, 145, 90, 55);
  }
  popMatrix();
}

void dibujarJuego() {
  if (estado == 1) {
    heroe.actualizar(gravedad);
    if (heroe.pos.x > width / 2) camaraX = heroe.pos.x - width / 2;
    if (heroe.pos.y > height + 100) heroe.vidas = 0;
    if (heroe.vidas <= 0) estado = 2;
  } else {
    heroe.teclaIzquierda = false;
    heroe.teclaDerecha = false;
  }

  dibujarNubesBucle(camaraX * 0.3);
  stroke(0);
  heroe.enElSuelo = false;

  int bloqueInicio = floor(camaraX / anchoSuelo);
  int bloquesVisibles = ceil(width / anchoSuelo) + 1;

  pushMatrix();
  translate(-camaraX, 0);
  
  sala.dibujar(camaraX, width);

  fill(34, 139, 34);
  for (int i = bloqueInicio; i <= bloqueInicio + bloquesVisibles; i++) {
    float sueloX = i * anchoSuelo;
    rect(sueloX, 500, anchoSuelo, 100);
    heroe.verificarColisionSuelo(sueloX, 500, anchoSuelo);
  }

  for (int i = listaPlataformas.size() - 1; i >= 0; i--) {
    Plataforma plat = listaPlataformas.get(i);
    plat.mostrar();
    heroe.verificarColisionSuelo(plat.pos.x, plat.pos.y, plat.ancho);
    if (estado == 1 && plat.pos.x < camaraX - 200) listaPlataformas.remove(i);
  }

  float heroeCentroX = heroe.pos.x + (heroe.ancho / 2);
  float heroeCentroY = heroe.pos.y + (heroe.alto / 2);

  for (int i = listaEnemigos.size() - 1; i >= 0; i--) {
    Enemigo ene = listaEnemigos.get(i);
    if (estado == 1) ene.actualizar();
    ene.dibujar();

    if (estado == 1) {
      // COLISIÓN CON ATAQUE DE ESPADA (SISTEMA MELEE)
      if (heroe.verificarImpactoEnemigo(ene.pos.x, ene.pos.y, ene.radio)) {
        listaEnemigos.remove(i);
        continue;
      }

      float distancia = dist(heroeCentroX, heroeCentroY, ene.pos.x, ene.pos.y);
      if (distancia < ((heroe.ancho / 2) + ene.radio)) {
        if (heroe.vel.y > 0 && (heroe.pos.y + heroe.alto) < ene.pos.y + 10) {
          heroe.recibirDano();
          heroe.vel.y = -9;
          heroe.enElSuelo = false;
        } else {
          heroe.recibirDano();
        }
      }
    }
  }

  for (int i = listaMonedas.size() - 1; i >= 0; i--) {
    Moneda m = listaMonedas.get(i);
    if (estado == 1) m.actualizar();
    m.dibujar();

    if (estado == 1) {
      if (dist(heroeCentroX, heroeCentroY, m.pos.x, m.pos.y) < ((heroe.ancho / 2) + m.radio)) {
        monedasRecolectadas++;
        listaMonedas.remove(i);
      } else if (m.pos.x < camaraX - 200) {
        listaMonedas.remove(i);
      }
    }
  }

  if (estado == 1 && proximaPlataformaX < camaraX + width + 400) crearNuevaPlataforma();

  heroe.dibujar();
  popMatrix();
//hasta aca//

  // HUD: MÁSCARAS HOLLOW KNIGHT
  pushStyle();
  imageMode(CENTER);
  for (int i = 0; i < heroe.vidas; i++) {
    float mascaraX = 35 + (i * 35);
    float mascaraY = 40;
    if (heroe.invencible && estado == 1) {
      mascaraX += random(-2, 2);
      mascaraY += random(-2, 2);
    }
    image(imgMascara, mascaraX, mascaraY);
  }
  popStyle();

  textAlign(RIGHT, BASELINE);
  textSize(24);
  fill(255, 215, 0);
  stroke(0);
  strokeWeight(4);
  text("MONEDAS: " + monedasRecolectadas, width - 20, 40);
  textAlign(LEFT, BASELINE);

  if (estado == 2) {
    fill(0, 0, 0, 180);
    rect(0, 0, width, height);
    fill(255, 50, 50);
    textSize(50);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 20);
    fill(255);
    textSize(20);
    text("Presiona 'R' para volver a jugar", width / 2, height / 2 + 40);
    textAlign(LEFT, BASELINE);
  }
}
void crearNuevaPlataforma() {
  float aleatorioY = random(300, 450);
  Plataforma nuevaPlat = new Plataforma(proximaPlataformaX, aleatorioY);
  listaPlataformas.add(nuevaPlat);
  if (random(100) < 60) {
    int cantidadMonedas = (int)random(2, 5);
    float espacio = nuevaPlat.ancho / (cantidadMonedas + 1);
    for (int i = 1; i <= cantidadMonedas; i++) {
      listaMonedas.add(new Moneda(nuevaPlat.pos.x + (i * espacio), nuevaPlat.pos.y - 40, imgMoneda));
    }
  } else if (random(100) < 70) {
    float tipoEnemigo = random(100);
    if (tipoEnemigo < 50) {
      listaEnemigos.add(new Enemigo(nuevaPlat, 20, imgEneFuego));
    } else {
      listaEnemigos.add(new EnemigoVolador(nuevaPlat, 20, imgEneFantasma));
    }
  }
  proximaPlataformaX += nuevaPlat.ancho + random(100, 250);
}

void dibujarPantallaPausa() {
  // Fondo oscuro semi-transparente para oscurecer el juego congelado
  fill(0, 0, 0, 150);
  rect(0, 0, width, height);

  textAlign(CENTER, CENTER);
  textFont(fuenteMedieval);

  // Título de PAUSA con un parpadeo/brillo sutil
  float opacidadPausa = map(sin(frameCount * 0.08), -1, 1, 180, 255);
  fill(0, 0, 0, 150);
  text("JUEGO PAUSADO", width / 2 + 4, height / 4 + 4);
  fill(130, 0, 0, opacidadPausa);
  text("JUEGO PAUSADO", width / 2, height / 4);

  // Configuración de los 3 botones medievales
  float botonAncho = 240;
  float botonAlto = 50;
  float centroX = width / 2;
  float inicioY = height / 2 - 50;

  float btnReanudarY = inicioY;
  float btnReiniciarY = inicioY + 65;
  float btnMenuY = inicioY + 130;

  // Dibujamos las tres opciones con el estilo medieval existente
  dibujarBotonMedieval(centroX - (botonAncho / 2), btnReanudarY, botonAncho, botonAlto, "REANUDAR (P)");
  dibujarBotonMedieval(centroX - (botonAncho / 2), btnReiniciarY, botonAncho, botonAlto, "REINICIAR NIVEL");
  dibujarBotonMedieval(centroX - (botonAncho / 2), btnMenuY, botonAncho, botonAlto, "MENU PRINCIPAL");
}


void mousePressed() {
  if (estado == 0) {
    float botonAncho = 260;
    float botonAlto = 55;
    float centroX = width / 2;
    float btnJugarX = centroX - (botonAncho / 2);
    float btnJugarY = (height / 2) - 10;
    float btnAyudaX = centroX - (botonAncho / 2);
    float btnAyudaY = (height / 2) + 70;
    if (mouseX > btnJugarX && mouseX < btnJugarX + botonAncho && mouseY > btnJugarY && mouseY < btnJugarY + botonAlto) {
      reiniciarJuego();
    }
    if (mouseX > btnAyudaX && mouseX < btnAyudaX + botonAncho && mouseY > btnAyudaY && mouseY < btnAyudaY + botonAlto) {
      estado = 3;
    }
  } else if (estado == 3) {
    float volverX = width / 2 - 80;
    float volverY = height / 3 + 350; // <-- Cambiar a 350 para alinearlo con el dibujo
    float volverAncho = 160;
    float volverAlto = 45;

    if (mouseX > volverX && mouseX < volverX + volverAncho && mouseY > volverY && mouseY < volverY + volverAlto) {
      estado = 0;
    }
  } else if (estado == 4) {
    float botonAncho = 240;
    float botonAlto = 50;
    float centroX = width / 2;
    float inicioY = height / 2 - 50;

    float btnReanudarY = inicioY;
    float btnReiniciarY = inicioY + 65;
    float btnMenuY = inicioY + 130;

    if (mouseX > centroX - (botonAncho / 2) && mouseX < centroX + (botonAncho / 2) && mouseY > btnReanudarY && mouseY < btnReanudarY + botonAlto) {
      estado = 1;
    }
    if (mouseX > centroX - (botonAncho / 2) && mouseX < centroX + (botonAncho / 2) && mouseY > btnReiniciarY && mouseY < btnReiniciarY + botonAlto) {
      reiniciarJuego();
    }
    if (mouseX > centroX - (botonAncho / 2) && mouseX < centroX + (botonAncho / 2) && mouseY > btnMenuY && mouseY < btnMenuY + botonAlto) {
      estado = 0;
    }
  }
}
