class Moneda {
  float x, y;
  float radio;
  float anguloGiro;
  PImage sprite;

  Moneda(float xInicial, float yInicial) {
    this.x = xInicial;
    this.y = yInicial;
    this.radio = 12; // Un poquito más grande para que se aprecie el PNG
    this.anguloGiro = random(TWO_PI); 
    
    // Cargamos la imagen de la moneda
    this.sprite = loadImage("puntos reales.png");
  }

  void actualizar() {
    anguloGiro += 0.08; 
  }

  void dibujar() {
    if (sprite != null) {
      pushStyle();
      imageMode(CENTER); // Centramos el dibujo en sus coordenadas X e Y
      
      // Calculamos el ancho usando el seno para simular el giro 3D horizontal
      float escalaAncho = sin(anguloGiro);
      float anchoActual = radio * 2 * abs(escalaAncho);
      
      if (anchoActual < 2) anchoActual = 2; // Evita que desaparezca por completo en el giro
      
      // Dibujamos el PNG estrujado horizontalmente según el giro
      image(sprite, x, y, anchoActual, radio * 2);
      popStyle();
    } else {
      // Respaldo geométrico por si el archivo PNG no carga
      pushStyle();
      ellipseMode(CENTER);
      noStroke();
      float escalaAncho = sin(anguloGiro);
      float anchoActual = radio * 2 * abs(escalaAncho);
      if (anchoActual < 2) anchoActual = 2;
      fill(218, 165, 32);
      ellipse(x, y, anchoActual + 4, radio * 2 + 4);
      fill(255, 223, 0);
      ellipse(x, y, anchoActual, radio * 2);
      popStyle();
    }
  }
}
