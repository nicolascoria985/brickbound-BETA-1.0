class Jugador {
  // Propiedades básicas
  float x, y;
  float ancho, alto;
  float velX, velY;
  
  // Propiedades de juego y vidas
  int vidas;
  boolean invencible;
  int tiempoInvencible;
  
  // Físicas pulidas
  float velocidadMaxima = 6;
  float aceleracion = 0.5;
  float friccion = 0.85;
  float impulsoSalto = -11.5;
  boolean enElSuelo;
  
  // Dirección para orientar el Sprite (1 = Derecha, -1 = Izquierda)
  int direccion = 1; 
  
  // Estados de control
  boolean teclaIzquierda = false;
  boolean teclaDerecha = false;
  
  // Propiedades de ataque
  int cooldownDisparo = 0;      
  int cadenciaDisparo = 20;     
  
  // --- NUEVAS VARIABLES DE ANIMACIÓN ---
  PImage imgIdle;
  PImage imgJump;
  PImage[] imgRun; // Arreglo para guardar los fotogramas de correr
  int totalFotogramasCorrer = 3; // Cambia este número según cuántas imágenes de correr uses
  float frameActual = 0;
  float velocidadAnimacion = 0.2; // Qué tan rápido cambian los pies al correr

  // Constructor
  Jugador(float xInicial, float yInicial) {
    x = xInicial;
    y = yInicial;
    ancho = 55;
    alto = 75;
    velX = 0;
    velY = 0;
    enElSuelo = false;
    
    vidas = 3;
    invencible = false;
    tiempoInvencible = 0;
    
    // --- CARGA DE ANIMACIONES ---
    // NOTA: Asegúrate de tener estos archivos exactos en tu carpeta 'data'
    imgIdle = loadImage("centinela.png");
    imgJump = loadImage("centinela_saltando.png");
    
    imgRun = new PImage[totalFotogramasCorrer];
    for (int i = 0; i < totalFotogramasCorrer; i++) {
      imgRun[i] = loadImage("centinela_corriendo.png");
    }
  }
  
  // Procesa movimiento y físicas
  void actualizar(float gravedad) {
    if (teclaIzquierda) {
      velX -= aceleracion;
      direccion = -1; 
    } else if (teclaDerecha) {
      velX += aceleracion;
      direccion = 1;  
    } else {
      velX *= friccion; 
    }
    
    velX = constrain(velX, -velocidadMaxima, velocidadMaxima);
    x += velX;
    
    if (x < 0) {
      x = 0;
      velX = 0;
    }
    
    velY += gravedad;
    velY = constrain(velY, -20, 15); 
    y += velY;
    
    if (invencible) {
      tiempoInvencible--;
      if (tiempoInvencible <= 0) {
        invencible = false;
      }
    }
    
    if (cooldownDisparo > 0) {
      cooldownDisparo--;
    }
    
    // --- ACTUALIZACIÓN DEL FOTOGRAMA DE CAMINATA ---
    if (enElSuelo && abs(velX) > 0.2) {
      frameActual += velocidadAnimacion;
      if (frameActual >= totalFotogramasCorrer) {
        frameActual = 0; // Reinicia el ciclo de caminata
      }
    } else {
      frameActual = 0; // Si se detiene, vuelve al primer fotograma
    }
  }
  
  // El método dibujar ahora decide de forma interna qué sprite mostrar
  // Ignoramos el PImage img del parámetro viejo para no romper tu pestaña principal
  void dibujar(PImage imgIgnorada) {
    if (invencible && frameCount % 6 < 3) {
      return; 
    }
    
    // --- SELECCIÓN INTELIGENTE DEL SPRITE ---
    PImage spriteActual = imgIdle; // Sprite por defecto
    
    if (!enElSuelo) {
      spriteActual = imgJump; // Si está en el aire, usa el de salto
    } else if (abs(velX) > 0.2) {
      spriteActual = imgRun[int(frameActual)]; // Si corre en el suelo, usa el índice del ciclo
    }
    
    pushMatrix();
    
    if (spriteActual != null) {
      if (direccion == -1) {
        translate(x + ancho, y);
        scale(-1, 1);
        image(spriteActual, 0, 0, ancho, alto);
      } else {
        translate(x, y);
        image(spriteActual, 0, 0, ancho, alto);
      }
    } else {
      translate(x, y);
      fill(220, 50, 50); 
      stroke(0);
      strokeWeight(2);
      rect(0, 0, ancho, alto, 4);
    }
    
    popMatrix();
  }
  
  void saltar() {
    if (enElSuelo) {
      velY = impulsoSalto;
      enElSuelo = false;
    }
  }
  
  void verificarColisionSuelo(float sueloX, float sueloY, float sueloAncho) {
    if (x + ancho > sueloX && x < sueloX + sueloAncho) {
      if (velY >= 0 && y + alto >= sueloY && y + alto <= sueloY + velY + 4) {
        y = sueloY - alto; 
        velY = 0;
        enElSuelo = true;
      }
    }
  }
  
  void recibirDano() {
    if (!invencible) {
      vidas--;
      invencible = true;
      tiempoInvencible = 60; 
      velY = -6; 
    }
  }
  
  void disparar(ArrayList<Proyectil> lista) {
    if (cooldownDisparo == 0) {
      float origenX = (direccion == 1) ? (x + ancho) : x;
      float origenY = y + (alto / 2);
      Proyectil nuevoProyectil = new Proyectil(origenX, origenY, direccion, "jugador");
      lista.add(nuevoProyectil);
      cooldownDisparo = cadenciaDisparo;
    }
  }
}
