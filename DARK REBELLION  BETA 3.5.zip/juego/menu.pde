void dibujarMenuInicio() {
  image(imgMenu, 0, 0);
  strokeWeight(2);

  // TÍTULO CON EFECTO DE DESVANECIMIENTO CONTINUO Y RESPLANDOR ROJO (GLOW)
  textAlign(CENTER, CENTER);
  textFont(fuenteMedieval);
  
  float opacidadBase = map(sin(frameCount * 0.05), -1, 1, 60, 255);
  float tituloX = width / 2;
  float tituloY = height / 4;


  int radioResplandor = 6; 
  for (int i = 1; i <= radioResplandor; i++) {
    float opacidadBrillo = map(i, 1, radioResplandor, opacidadBase * 0.4, 2);
    fill(200, 0, 0, opacidadBrillo);
    text("DARK REBELLION", tituloX - i, tituloY);
    text("DARK REBELLION", tituloX + i, tituloY);
    text("DARK REBELLION", tituloX, tituloY - i);
    text("DARK REBELLION", tituloX, tituloY + i);
    text("DARK REBELLION", tituloX - i, tituloY - i);
    text("DARK REBELLION", tituloX + i, tituloY + i);
  }
  
  fill(130, 0, 0, opacidadBase); 
  text("DARK REBELLION", tituloX, tituloY);

  // CONFIGURACIÓN DE LOS BOTONES ESTILO MEDIEVAL INTERACTIVOS
  float botonAncho = 260;
  float botonAlto = 55;
  float centroX = width / 2;
  
  float btnJugarX = centroX - (botonAncho / 2);
  float btnJugarY = (height / 2) - 10;
  
  float btnAyudaX = centroX - (botonAncho / 2);
  float btnAyudaY = (height / 2) + 70;

  dibujarBotonMedieval(btnJugarX, btnJugarY, botonAncho, botonAlto, "ENTER PARA EMPEZAR");
  dibujarBotonMedieval(btnAyudaX, btnAyudaY, botonAncho, botonAlto, "AYUDA / CONTROLES");
  
  textAlign(LEFT, BASELINE);
}

void dibujarBotonMedieval(float x, float y, float ancho, float alto, String texto) {
  boolean mouseEncima = (mouseX > x && mouseX < x + ancho && mouseY > y && mouseY < y + alto);
  pushStyle();
  rectMode(CORNER);
  
  if (mouseEncima) {
    noFill();
    for (int i = 1; i <= 8; i++) {
      stroke(180, 0, 0, map(i, 1, 8, 45, 2));
      strokeWeight(i * 2);
      rect(x - i, y - i, ancho + (i * 2), alto + (i * 2), 8);
    }
  }
  
  if (mouseEncima) {
    fill(40, 10, 10, 230);    
    stroke(180, 0, 0);         
    strokeWeight(2.5);
  } else {
    fill(20, 20, 20, 210);    
    stroke(120, 100, 70);     
    strokeWeight(2);
  }
  rect(x, y, ancho, alto, 4);

  if (mouseEncima) fill(220, 0, 0); else fill(160, 140, 110);
  noStroke();
  rect(x + 4, y + 4, 4, 4);
  rect(x + ancho - 8, y + 4, 4, 4);
  rect(x + 4, y + alto - 8, 4, 4);
  rect(x + ancho - 8, y + alto - 8, 4, 4);

  textAlign(CENTER, CENTER);
  if (mouseEncima) fill(255, 200, 200); else fill(210, 190, 160);
  textSize(14);
  text(texto, x + (ancho / 2), y + (alto / 2) - 2);
  popStyle();
}
void dibujarPantallaAyuda() {
  image(imgMenu, 0, 0);
  fill(0, 0, 0, 200);
  rect(0, 0, width, height);

  textAlign(CENTER, CENTER);
  fill(255, 215, 0);
  textSize(40);
  text("GUÍA DE CONTROLES", width / 2, height / 4 - 60); // Subimos un poco el título principal

  // --- 1. RECTÁNGULO DE FONDO AGRANDADO ---
  // Cambiamos el alto de 310 a 420 para que quepa todo el nuevo contenido
  fill(20, 20, 20, 180);
  stroke(255, 100);
  rect(width / 2 - 250, height / 3 - 40, 500, 420, 15); 

  // --- 2. TEXTOS AJUSTADOS Y SEPARADOS HORIZONTALMENTE ---
  fill(255); textSize(18); text("MOVIMIENTO", width / 2, height / 3 - 10);
  fill(200); textSize(15); text("Teclas 'A' / 'D'   o   Flechas Izquierda / Derecha", width / 2, height / 3 + 15);

  fill(255); textSize(18); text("SALTAR (CON DOBLE SALTO)", width / 2, height / 3 + 65);
  fill(200); textSize(15); text("Tecla 'W'   o   Flecha Arriba   o   Barra Espaciadora", width / 2, height / 3 + 90);

  fill(255); textSize(18); text("ATACAR (CUERPO A CUERPO)", width / 2, height / 3 + 140);
  fill(200); textSize(15); text("Tecla 'G'", width / 2, height / 3 + 165); // <-- Actualizado a la tecla G

  fill(255); textSize(18); text("DASH (EVADIR / IMPULSO)", width / 2, height / 3 + 215);
  fill(200); textSize(15); text("Tecla 'SHIFT' (Mayús)", width / 2, height / 3 + 240);

  fill(255); textSize(18); text("PAUSAR JUEGO", width / 2, height / 3 + 290);
  fill(200); textSize(15); text("Tecla 'P'", width / 2, height / 3 + 315);

  // --- 3. BOTÓN VOLVER DESPLAZADO MÁS ABAJO ---
  // Cambiamos su posición Y (height / 3 + 350) para que no se choque con los textos
  float volverX = width / 2 - 80;
  float volverY = height / 3 + 350; 
  float volverAncho = 160;
  float volverAlto = 45;

  if (mouseX > volverX && mouseX < volverX + volverAncho && mouseY > volverY && mouseY < volverY + volverAlto) {
    fill(80, 80, 80);
  } else {
    fill(40, 40, 40);
  }
  rect(volverX, volverY, volverAncho, volverAlto, 8);
  
  fill(255); textSize(16);
  text("VOLVER (ESC)", width / 2, volverY + (volverAlto / 2));
  textAlign(LEFT, BASELINE);
}
