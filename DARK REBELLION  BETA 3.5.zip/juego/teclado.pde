void keyPressed() {
  // PANTALLA DE PAUSA (Estado 4)
  if (estado == 4) {
    if (key == 'p' || key == 'P' || keyCode == ESC) {
      estado = 1; // Quita la pausa y reanuda la partida
      key = 0;    // Detiene el cierre forzado nativo de Processing al presionar ESC
    }
    return;
  }
  
  // PANTALLA DE AYUDA (Estado 3)
  if (estado == 3) {
    if (keyCode == ESC || keyCode == BACKSPACE) {
      estado = 0; 
      key = 0; 
    }
    return;
  }

  // MENÚ DE INICIO (Estado 0)
  if (estado == 0) {
    if (keyCode == ENTER || keyCode == RETURN) {
      reiniciarJuego();
    }
    return;
  }

  // GAME OVER (Estado 2)
  if (estado == 2) {
    if (key == 'r' || key == 'R') {
      reiniciarJuego();
    }
    return;
  }

  // JUEGO ACTIVO (Estado 1)
  if (estado == 1) {
    if (keyCode == LEFT  || key == 'a' || key == 'A') heroe.teclaIzquierda = true;
    if (keyCode == RIGHT || key == 'd' || key == 'D') heroe.teclaDerecha = true;
    if (keyCode == UP    || key == 'w' || key == 'W' || key == ' ') heroe.saltar();
    if (key == 'g'       || key == 'G') heroe.atacar(); // Mapeado a la tecla G
    if (keyCode == SHIFT) heroe.ejecutarDash();
    
    // --- CORREGIDO: Activar la pausa desde la partida activa ---
    if (key == 'p' || key == 'P') {
      estado = 4;
    }
  }
}

void keyReleased() {
  if (estado == 1) {
    if (keyCode == LEFT  || key == 'a' || key == 'A') heroe.teclaIzquierda = false;
    if (keyCode == RIGHT || key == 'd' || key == 'D') heroe.teclaDerecha = false;
  }
}
