class Enemigo {
  PVector pos, vel;
  float radio, limiteIzquierdo, limiteDerecho;
  PImage imgSprite;
  boolean persiguiendo = false;
  float rangoAlerta = 200;

  Enemigo(Plataforma plat, float radio, PImage img) {
    this.radio = radio;
    imgSprite = img;
    pos = new PVector(plat.pos.x + plat.ancho / 2, plat.pos.y - radio);
    vel = new PVector(1.5, 0);
    limiteIzquierdo = plat.pos.x + radio;
    limiteDerecho = plat.pos.x + plat.ancho - radio;
  }

  void actualizar() {
    pos.add(vel);
    if (pos.x <= limiteIzquierdo) { pos.x = limiteIzquierdo; vel.x *= -1; }
    if (pos.x >= limiteDerecho) { pos.x = limiteDerecho; vel.x *= -1; }

    if (heroe != null) {
      float distanciaAlHeroe = dist(pos.x, pos.y, heroe.pos.x, heroe.pos.y);
      if (distanciaAlHeroe < rangoAlerta && heroe.pos.y > pos.y - 50 && heroe.pos.y < pos.y + 50) {
        persiguiendo = true;
        if (heroe.pos.x > pos.x) vel.x = 3.0; else vel.x = -3.0;
      } else if (persiguiendo) {
        persiguiendo = false;
        vel.x = (vel.x > 0) ? 1.5 : -1.5;
      }
    }
  }

  void dibujar() {
    if (persiguiendo) {
      pushStyle(); tint(255, 150, 150);
      image(imgSprite, pos.x - radio, pos.y - radio, radio * 2, radio * 2);
      popStyle();
    } else {
      image(imgSprite, pos.x - radio, pos.y - radio, radio * 2, radio * 2);
    }
  }
}

// =========================================================================
// 3. CLASE: ENEMIGO VOLADOR (FANTASMA)
// =========================================================================
class EnemigoVolador extends Enemigo {
  float anguloFlotar = 0, yOriginal;
  float rangoDeteccionAerea = 280;

  EnemigoVolador(Plataforma plat, float radio, PImage img) {
    super(plat, radio, img);
    pos.y -= 50;
    yOriginal = pos.y;
    vel = new PVector(2.0, 0);
  }

  void actualizar() {
    anguloFlotar += 0.05;
    if (heroe != null) {
      float distanciaAlHeroe = dist(pos.x, pos.y, heroe.pos.x, heroe.pos.y);
      if (distanciaAlHeroe < rangoDeteccionAerea) {
        persiguiendo = true;
        PVector objetivo = new PVector(heroe.pos.x + heroe.ancho/2, heroe.pos.y + heroe.alto/2);
        PVector direccion = PVector.sub(objetivo, pos);
        direccion.normalize(); direccion.mult(2.5);
        pos.add(direccion);
        yOriginal = pos.y; 
      } else {
        if (persiguiendo) { persiguiendo = false; vel.set(2.0, 0); }
        pos.x += vel.x;
        if (pos.x <= limiteIzquierdo) { pos.x = limiteIzquierdo; vel.x *= -1; }
        if (pos.x >= limiteDerecho) { pos.x = limiteDerecho; vel.x *= -1; }
        pos.y = yOriginal + sin(anguloFlotar) * 20;
      }
    }
  }
}

// =========================================================================
// 4. NUEVA CLASE: FRANCOTIRADOR (AGUJA SOMBRÍA)
// =========================================================================
class EnemigoDisparador extends Enemigo {
  int cronometroDisparo = 0;
  int tiempoEntreDisparos = 100; // Un disparo cada ~1.6 segundos
  float rangoDisparo = 350;      // Rango de visión de disparo
  float distanciaSegura = 180;   // Distancia que quiere mantener con el héroe

  EnemigoDisparador(Plataforma plat, float radio, PImage img) {
    super(plat, radio, img);
    vel.x = 1.2; // Camina un poco más lento por defecto
  }

  void actualizar() {
    if (heroe == null) return;

    float heroeCentroX = heroe.pos.x + (heroe.ancho / 2);
    float heroeCentroY = heroe.pos.y + (heroe.alto / 2);
    float distanciaAlHeroe = dist(pos.x, pos.y, heroeCentroX, heroeCentroY);

    // CONTROL DE DISTANCIA DE SEGURIDAD (Se comporta como francotirador)
    if (distanciaAlHeroe < rangoDisparo) {
      persiguiendo = true;

      // Si el héroe se acerca demasiado, el enemigo camina EN RETROCESO (mantiene distancia)
      if (distanciaAlHeroe < distanciaSegura) {
        if (heroeCentroX > pos.x) {
          pos.x -= vel.x; // El héroe está a la derecha, el enemigo huye a la izquierda
        } else {
          pos.x += vel.x; // El héroe está a la izquierda, el enemigo huye a la derecha
        }
      } 
      // Si está en el rango correcto pero no tan cerca, se queda quieto apuntando
      else {
        // No se mueve, se concentra en apuntar
      }
      
      // Restringir que al retroceder o moverse no se caiga de su plataforma asignada
      pos.x = constrain(pos.x, limiteIzquierdo, limiteDerecho);

      // LÓGICA DE DISPARO EN CUALQUIER ÁNGULO
      cronometroDisparo++;
      if (cronometroDisparo >= tiempoEntreDisparos) {
        // Calculamos el ángulo trigonométrico exacto en radianes desde el enemigo hacia el jugador
        float anguloHaciaHeroe = atan2(heroeCentroY - pos.y, heroeCentroX - pos.x);
        
        // Añadimos el nuevo proyectil a una lista global (la manejaremos en el loop principal)
        listaProyectiles.add(new Proyectil(pos.x, pos.y - 10, anguloHaciaHeroe));
        cronometroDisparo = 0;
      }
    } 
    // Si el héroe no está cerca, patrulla tranquilamente la plataforma
    else {
      persiguiendo = false;
      pos.x += vel.x;
      if (pos.x <= limiteIzquierdo) { pos.x = limiteIzquierdo; vel.x *= -1; }
      if (pos.x >= limiteDerecho) { pos.x = limiteDerecho; vel.x *= -1; }
    }
  }
}
