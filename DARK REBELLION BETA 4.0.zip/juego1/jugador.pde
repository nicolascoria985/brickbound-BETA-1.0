class Jugador {
  PVector pos;
  PVector vel;
  float ancho, alto;

  int vidas;
  boolean invencible;
  int tiempoInvencible;

  float velocidadMaxima = 6;
  float aceleracion = 0.5;
  float friccion = 0.85;
  float impulsoSalto = -11.5;
  boolean enElSuelo;
  
  int saltosRealizados = 0; 
  int direccion = 1;

  boolean teclaIzquierda = false;
  boolean teclaDerecha = false;
  
  boolean estaAtacando = false;
  int duracionAtaque = 0;      
  int maxDuracionAtaque = 12;   
  int cooldownAtaque = 0;       
  int maxCooldownAtaque = 25;  
  float alcanceAtaque = 45;     

  boolean estaHaciendoDash = false;
  int duracionDash = 0;         
  int maxDuracionDash = 10;     
  int cooldownDash = 0;         
  int maxCooldownDash = 45;     
  float velocidadDash = 16;     

  // Animaciones actualizadas por referencia
  PImage imgIdle, imgJump, imgAttackSprite, imgDashSprite;
  PImage[] imgRunAnim;          // <-- Arreglo de referencias para los frames de carrera
  int totalFotogramasCorrer = 2;
  float frameActual = 0;
  float velocidadAnimacion = 0.050; // Qué tan rápido cambian los pies de posición

  Jugador(float xInicial, float yInicial, PImage idle, PImage jump, PImage[] run, PImage attack, PImage dash) {
    pos = new PVector(xInicial, yInicial);
    vel = new PVector(0, 0);
    ancho = 55;
    alto = 75;
    enElSuelo = false;

    vidas = 3;
    invencible = false;
    tiempoInvencible = 0;

    imgIdle = idle;
    imgJump = jump;
    imgRunAnim = run; // <-- Guardamos la colección de fotogramas
    imgAttackSprite = attack;
    imgDashSprite = dash;
  }

  void actualizar(float gravedad) {
    if (estaHaciendoDash) {
      vel.x = velocidadDash * direccion;
      vel.y = 0;
      duracionDash--;
      if (duracionDash <= 0) {
        estaHaciendoDash = false;
        vel.x = velocidadMaxima * direccion;
      }
    } else {
      if (teclaIzquierda) {
        vel.x -= aceleracion;
        direccion = -1;
      } else if (teclaDerecha) {
        vel.x += aceleracion;
        direccion = 1;
      } else {
        vel.x *= friccion;
      }
      vel.x = constrain(vel.x, -velocidadMaxima, velocidadMaxima);
    }

    pos.x += vel.x;

    if (pos.x < 0) {
      pos.x = 0;
      vel.x = 0;
    }

    if (!estaHaciendoDash) {
      vel.y += gravedad;
      vel.y = constrain(vel.y, -20, 15);
    }
    pos.y += vel.y;

    if (invencible) {
      tiempoInvencible--;
      if (tiempoInvencible <= 0) {
        invencible = false;
      }
    }

    // --- MANEJO AVANZADO DE ANIMACIÓN DE CARRERA ---
    if (enElSuelo && abs(vel.x) > 0.2) {
      // Escalamos la velocidad de la animación según qué tan rápido se mueva físicamente
      // Esto hace que si camina lento, los pies se muevan lento, y si corre, vayan rápido
      frameActual += (abs(vel.x) / velocidadMaxima) * velocidadAnimacion;
      
      if (frameActual >= totalFotogramasCorrer) {
        frameActual = 0; // Regresa al primer fotograma al terminar el ciclo
      }
    } else {
      frameActual = 0; // Si se detiene, la animación se congela en el cuadro inicial
    }
    
    if (estaAtacando) {
      duracionAtaque--;
      if (duracionAtaque <= 0) {
        estaAtacando = false;
      }
    }
    if (cooldownAtaque > 0) cooldownAtaque--;
    if (cooldownDash > 0) cooldownDash--;
  }

  void dibujar() {
    if (invencible && frameCount % 6 < 3) {
      return;
    }

    PImage spriteActual = imgIdle;

    // Asignación de estados visuales prioritarios
    if (estaHaciendoDash) {
      spriteActual = imgDashSprite;   
    } else if (estaAtacando) {
      spriteActual = imgAttackSprite; 
    } else if (!enElSuelo) {
      spriteActual = imgJump;
    } else if (abs(vel.x) > 0.2 && imgRunAnim != null) {
      // Tomamos el fotograma actual convirtiendo el float a un número entero (int)
      int indiceFrame = floor(frameActual);
      spriteActual = imgRunAnim[indiceFrame]; // <-- NUEVO: Selecciona el frame dinámico de la lista
    }

    pushMatrix();
    if (spriteActual != null) {
      if (direccion == -1) {
        translate(pos.x + ancho, pos.y);
        scale(-1, 1);
        image(spriteActual, 0, 0, ancho, alto);
      } else {
        translate(pos.x, pos.y);
        image(spriteActual, 0, 0, ancho, alto);
      }
    } else {
      translate(pos.x, pos.y);
      fill(220, 50, 50); stroke(0); strokeWeight(2);
      rect(0, 0, ancho, alto, 4);
    }
    popMatrix();
  }

  void saltar() {
    if (enElSuelo) {
      vel.y = impulsoSalto;
      enElSuelo = false;
      saltosRealizados = 1;
    } else if (saltosRealizados < 2) {
      vel.y = impulsoSalto * 0.9; 
      saltosRealizados = 2;
    }
  }

  void verificarColisionSuelo(float sueloX, float sueloY, float sueloAncho) {
    if (pos.x + ancho > sueloX && pos.x < sueloX + sueloAncho) {
      if (vel.y >= 0 && pos.y + alto >= sueloY && pos.y + alto <= sueloY + vel.y + 4) {
        pos.y = sueloY - alto;
        vel.y = 0;
        enElSuelo = true;
        saltosRealizados = 0; 
      }
    }
  }

  void recibirDano() {
    if (!invencible) {
      vidas--;
      invencible = true;
      tiempoInvencible = 60;
      vel.y = -6;
    }
  }

  void atacar() {
    if (!estaAtacando && cooldownAtaque <= 0) {
      estaAtacando = true;
      duracionAtaque = maxDuracionAtaque;
      cooldownAtaque = maxCooldownAtaque;
    }
  }

  boolean verificarImpactoEnemigo(float eneX, float eneY, float eneRadio) {
    if (!estaAtacando) return false;

    float ataqueX = (direccion == 1) ? (pos.x + ancho) : (pos.x - alcanceAtaque);
    float ataqueY = pos.y + (alto / 4);
    float ataqueAncho = alcanceAtaque;
    float ataqueAlto = alto / 2;

    float cercanoX = constrain(eneX, ataqueX, ataqueX + ataqueAncho);
    float cercanoY = constrain(eneY, ataqueY, ataqueY + ataqueAlto);
    
    float distanciaCuadrada = pow(eneX - cercanoX, 2) + pow(eneY - cercanoY, 2);
    return distanciaCuadrada < pow(eneRadio, 2);
  }


void ejecutarDash() {
    if (!estaHaciendoDash && cooldownDash <= 0) {
      estaHaciendoDash = true;
      duracionDash = maxDuracionDash;
      cooldownDash = maxCooldownDash;
      invencible = true;
      tiempoInvencible = maxDuracionDash + 5; 
    }
  }
}
