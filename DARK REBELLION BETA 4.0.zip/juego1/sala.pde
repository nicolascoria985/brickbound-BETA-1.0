// =====================================================================
// sala.pde  -  Carga y dibuja una sala hecha en Tiled (.tmx)
// Requiere en la carpeta data/:  Nivel_01.tmx  y  tileset_nivel01.png
// =====================================================================

class CapaTiles {
  String nombre;
  int[][] gid;                       // [fila][columna]
}

class ObjetoMapa {
  int id;
  String tipo;                       // la Class que pusiste en Tiled (jugador, enemigo...)
  float x, y, ancho, alto;           // ya convertidos a píxeles de pantalla
  HashMap<String, String> props = new HashMap<String, String>();

  String texto(String clave, String porDefecto) {
    return props.containsKey(clave) ? props.get(clave) : porDefecto;
  }

  int entero(String clave, int porDefecto) {
    return props.containsKey(clave) ? parseInt(props.get(clave)) : porDefecto;
  }
}

class Sala {
  int columnas, filas;
  float tile;                        // tamaño de un tile en pantalla
  float anchoMundo, altoMundo;
  ArrayList<CapaTiles> capas = new ArrayList<CapaTiles>();
  CapaTiles colision;
  ArrayList<ObjetoMapa> objetos = new ArrayList<ObjetoMapa>();
  PImage[] tiles;                    // el índice es el gid de Tiled

  Sala(String archivoMapa, String archivoTileset, float tileEnPantalla) {
    tile = tileEnPantalla;
    XML mapa = loadXML(archivoMapa);
    columnas = mapa.getInt("width");
    filas = mapa.getInt("height");
    float escala = tile / mapa.getInt("tilewidth");
    anchoMundo = columnas * tile;
    altoMundo = filas * tile;

    cargarTileset(mapa.getChild("tileset"), archivoTileset);

    // Capas de tiles
    for (XML c : mapa.getChildren("layer")) {
      CapaTiles capa = new CapaTiles();
      capa.nombre = c.getString("name");
      capa.gid = new int[filas][columnas];
      String[] valores = splitTokens(c.getChild("data").getContent(), ", \t\r\n");
      for (int i = 0; i < valores.length && i < filas * columnas; i++) {
        long bruto = Long.parseLong(valores[i]);
        capa.gid[i / columnas][i % columnas] = (int)(bruto & 0x0FFFFFFF);
      }
      capas.add(capa);
      if (capa.nombre.equals("colision")) colision = capa;
    }

    // Capa de objetos (jugador, enemigos, monedas, puertas)
    for (XML grupo : mapa.getChildren("objectgroup")) {
      for (XML o : grupo.getChildren("object")) {
        ObjetoMapa obj = new ObjetoMapa();
        obj.id = o.getInt("id");
        obj.tipo = o.getString("class", o.getString("type", ""));
        obj.x = o.getFloat("x") * escala;
        obj.y = o.getFloat("y") * escala;
        obj.ancho = o.getFloat("width", 0) * escala;
        obj.alto = o.getFloat("height", 0) * escala;
        XML propiedades = o.getChild("properties");
        if (propiedades != null) {
          for (XML p : propiedades.getChildren("property")) {
            obj.props.put(p.getString("name"), p.getString("value"));
          }
        }
        objetos.add(obj);
      }
    }
  }

  void cargarTileset(XML ts, String archivo) {
    PImage hoja = loadImage(archivo);
    int primerGid = ts.getInt("firstgid");
    int anchoTile = ts.getInt("tilewidth");
    int altoTile = ts.getInt("tileheight");
    int separacion = ts.getInt("spacing", 0);
    int margen = ts.getInt("margin", 0);
    int cols = ts.getInt("columns");
    int cantidad = ts.getInt("tilecount");
    tiles = new PImage[primerGid + cantidad];
    if (hoja == null) {
      println("No se encontró " + archivo + " en la carpeta data");
      return;
    }
    for (int i = 0; i < cantidad; i++) {
      int x = margen + (i % cols) * (anchoTile + separacion);
      int y = margen + (i / cols) * (altoTile + separacion);
      tiles[primerGid + i] = hoja.get(x, y, anchoTile, altoTile);
    }
  }

  // Dibuja todas las capas menos "frente" (esa va después del héroe)
  void dibujar(float camX, float anchoVisible) {
    for (CapaTiles capa : capas) {
      if (!capa.nombre.equals("frente")) dibujarCapa(capa, camX, anchoVisible);
    }
  }

  void dibujarFrente(float camX, float anchoVisible) {
    for (CapaTiles capa : capas) {
      if (capa.nombre.equals("frente")) dibujarCapa(capa, camX, anchoVisible);
    }
  }

  void dibujarCapa(CapaTiles capa, float camX, float anchoVisible) {
    int c0 = max(0, floor(camX / tile));
    int c1 = min(columnas - 1, floor((camX + anchoVisible) / tile));
    for (int f = 0; f < filas; f++) {
      for (int c = c0; c <= c1; c++) {
        int g = capa.gid[f][c];
        if (g > 0 && g < tiles.length && tiles[g] != null) {
          image(tiles[g], c * tile, f * tile, tile + 1, tile + 1);  // +1 evita costuras
        }
      }
    }
  }

  // Colisión: los bordes izquierdo y derecho de la sala son paredes; abajo es el vacío
  boolean esSolido(int col, int fila) {
    if (col < 0 || col >= columnas) return true;
    if (fila < 0 || fila >= filas) return false;
    return colision != null && colision.gid[fila][col] != 0;
  }

  boolean esSolidoEn(float x, float y) {
    return esSolido(floor(x / tile), floor(y / tile));
  }

  // Y del primer tile sólido hacia abajo desde un punto (para apoyar enemigos y héroe)
  float sueloBajo(float x, float desdeY) {
    int col = floor(x / tile);
    for (int f = max(0, floor(desdeY / tile)); f < filas; f++) {
      if (esSolido(col, f)) return f * tile;
    }
    return altoMundo;
  }

  // Primer objeto de un tipo (por ejemplo "jugador")
  ObjetoMapa primero(String tipo) {
    for (ObjetoMapa o : objetos) {
      if (o.tipo.equals(tipo)) return o;
    }
    return null;
  }
}
