import processing.sound.*;

ArrayList<Plataforma> listaPlataformas = new ArrayList<Plataforma>();
ArrayList<Enemigo> listaEnemigos = new ArrayList<Enemigo>();
ArrayList<Moneda> listaMonedas = new ArrayList<Moneda>();
ArrayList<Proyectil> listaProyectiles = new ArrayList<Proyectil>();

SoundFile musicaMenu; 

float proximaPlataformaX = 400;
Jugador heroe;
Sala sala;

// Texturas precargadas globales para optimizar rendimiento
PImage imgJugadorIdle, imgJugadorJump, imgJugadorAttack, imgJugadorDash;
PImage[] imgJugadorRunAnim;
PImage imgEneFuego, imgEneFantasma, imgEneSombra;
PImage imgMoneda;
PImage imgMenu, imgMascara;

float gravedad = 0.4;
float camaraX = 0;
float anchoSuelo = 400;
float anchoNubeBucle = 300;

int estado = 0, monedasRecolectadas = 0;

PFont fuenteMedieval;

void setup() {
  size(800, 600);

  // 1. Precarga de assets del Jugador
  imgJugadorIdle = loadImage("centinela.png");
  imgJugadorJump = loadImage("centinela_saltando.png");
  imgJugadorRunAnim = new PImage[2];
  for (int i = 0; i < imgJugadorRunAnim.length; i++) {
    imgJugadorRunAnim[i] = loadImage("centinela_corriendo" + i + ".png"); 
  }
  imgJugadorAttack = loadImage("golpe.png");
  imgJugadorDash = loadImage("dash.png");


  // 2. Precarga de assets de Enemigos y objetos
  imgEneFuego = loadImage("fantasma de fuego.png");
  imgEneFantasma = loadImage("fantasma.png");
  imgEneSombra = loadImage("agujasombria.png");
  imgMoneda = loadImage("puntos reales.png");

  // 3. Menu y HUD
  imgMenu = loadImage("menu.png");
  imgMenu.resize(0, height);
  imgMenu = imgMenu.get((imgMenu.width - width) / 2, 0, width, height);

  imgMascara = loadImage("mascara.png");
  imgMascara.resize(26, 0);

  fuenteMedieval = createFont("CloisterBlack.ttf", 64);
  musicaMenu = new SoundFile(this, "musica_menu.mp3"); 
  musicaMenu.loop(); // Usas el comando que te funcionó
  musicaMenu.play();

  //sala = new Sala("Nivel_01.tmx", "tileset_nivel01.png", height / 18.0);
  
  reiniciarJuego();
  estado = 0; // Iniciar en el menú principal
}

void draw() {
  switch (estado) {
  case 0:
    dibujarMenuInicio();
    break;
  case 1:
    background(35, 38, 42);
    dibujarJuego();
    break;
  case 2:
    background(135, 206, 235);
    dibujarJuego(); // Muestra el juego congelado detrás de la pantalla de Game Over
    break;
  case 3:
    dibujarPantallaAyuda();
    break;

  case 4:
    dibujarJuego();
    dibujarPantallaPausa();
    break;
  }
}

void reiniciarJuego() {
  // 1. Limpieza absoluta de las entidades del mapa anterior
  listaPlataformas.clear();
  listaEnemigos.clear();
  listaMonedas.clear();
  listaProyectiles.clear();

  monedasRecolectadas = 0;
  camaraX = 0;
  proximaPlataformaX = 400;

  if (musicaMenu != null) {
    musicaMenu.stop(); // Detiene el hilo de reproducción del menú de inicio
    musicaMenu.cue(0); // Reinicia el puntero del archivo de audio por seguridad
  }

  // 2. Creación del personaje con todos sus sprites optimizados
    // Reemplaza la línea del heroe por esta (le pasamos imgJugadorRunAnim):
  heroe = new Jugador(100, 300, imgJugadorIdle, imgJugadorJump, imgJugadorRunAnim, imgJugadorAttack, imgJugadorDash);


  // 3. Generación inicial de la partida
  crearNuevaPlataforma();
  crearNuevaPlataforma();
  crearNuevaPlataforma();

  // 4. Cambiar el estado al juego activo
  estado = 1;
}

//cosas que se iran
void dibujarNubesBucle(float camaraOffset) {
  int nubeInicio = floor(camaraOffset / anchoNubeBucle);
  int nubesVisibles = ceil(width / anchoNubeBucle) + 1;

  pushMatrix();
  translate(-camaraOffset, 0);
  
  // NUEVO: Color gris ceniza semi-transparente (Mucha opacidad baja para simular bruma)
  fill(70, 75, 80, 110); 
  noStroke();
  
  for (int i = nubeInicio; i <= nubeInicio + nubesVisibles; i++) {
    float nubeX = i * anchoNubeBucle;
    // Dibujamos las mismas elipses pero ahora actúan como masas de niebla pesada en el fondo
    ellipse(nubeX + 50, 110, 70, 40);
    ellipse(nubeX + 80, 100, 90, 50);
    ellipse(nubeX + 110, 110, 70, 40);
    ellipse(nubeX + 200, 160, 80, 35);
    ellipse(nubeX + 230, 155, 100, 45);
  }
  popMatrix();
}


void dibujarJuego() {
  if (estado == 1) {
    heroe.actualizar(gravedad);
    if (heroe.pos.x > width / 2) camaraX = heroe.pos.x - width / 2;
    if (heroe.pos.y > height + 100) heroe.vidas = 0;
    if (heroe.vidas <= 0) estado = 2;
  } else {
    heroe.teclaIzquierda = false;
    heroe.teclaDerecha = false;
  }

  dibujarNubesBucle(camaraX * 0.3);
  stroke(0);
  heroe.enElSuelo = false;

  int bloqueInicio = floor(camaraX / anchoSuelo);
  int bloquesVisibles = ceil(width / anchoSuelo) + 1;

  // =========================================================================
  // --- INICIO DEL ESPACIO DE MATRIZ DE CÁMARA (Coordenadas del Mundo) ---
  // =========================================================================
  pushMatrix();
  translate(-camaraX, 0);

  // Suelo Base
  fill(50, 45, 40);
  for (int i = bloqueInicio; i <= bloqueInicio + bloquesVisibles; i++) {
    float sueloX = i * anchoSuelo;
    rect(sueloX, 500, anchoSuelo, 100);
    heroe.verificarColisionSuelo(sueloX, 500, anchoSuelo);
  }

  // Plataformas flotantes
  for (int i = listaPlataformas.size() - 1; i >= 0; i--) {
    Plataforma plat = listaPlataformas.get(i);
    plat.mostrar();
    heroe.verificarColisionSuelo(plat.pos.x, plat.pos.y, plat.ancho);
    if (estado == 1 && plat.pos.x < camaraX - 200) listaPlataformas.remove(i);
  }

  float heroeCentroX = heroe.pos.x + (heroe.ancho / 2);
  float heroeCentroY = heroe.pos.y + (heroe.alto / 2);

  // Sistema de Enemigos
  for (int i = listaEnemigos.size() - 1; i >= 0; i--) {
    Enemigo ene = listaEnemigos.get(i);
    if (estado == 1) ene.actualizar();
    ene.dibujar();

    if (estado == 1) {
      // COLISIÓN CON ATAQUE DE ESPADA (SISTEMA MELEE)
      if (heroe.verificarImpactoEnemigo(ene.pos.x, ene.pos.y, ene.radio)) {
        listaEnemigos.remove(i);
        continue;
      }

      // Colisión física por contacto de cuerpos
      float distancia = dist(heroeCentroX, heroeCentroY, ene.pos.x, ene.pos.y);
      if (distancia < ((heroe.ancho / 2) + ene.radio)) {
        // CORREGIDO: Si cae sobre el enemigo lo elimina (antes decía heroe.recibirDano() en ambos)
        if (heroe.vel.y > 0 && (heroe.pos.y + heroe.alto) < ene.pos.y + 10) {
          heroe.recibirDano();
          heroe.vel.y = -9; // Impulso hacia arriba al rebotar en su cabeza
          heroe.enElSuelo = false;
        } else {
          heroe.recibirDano(); // El enemigo golpea al jugador por el frente
        }
      }
    }
  }

  // Monedas
  for (int i = listaMonedas.size() - 1; i >= 0; i--) {
    Moneda m = listaMonedas.get(i);
    if (estado == 1) m.actualizar();
    m.dibujar();

    if (estado == 1) {
      if (dist(heroeCentroX, heroeCentroY, m.pos.x, m.pos.y) < ((heroe.ancho / 2) + m.radio)) {
        monedasRecolectadas++;
        listaMonedas.remove(i);
      } else if (m.pos.x < camaraX - 200) {
        listaMonedas.remove(i);
      }
    }
  }

  // --- CORREGIDO: El control de proyectiles del Francotirador DEBE ir dentro de la matriz ---
  for (int i = listaProyectiles.size() - 1; i >= 0; i--) {
    Proyectil p = listaProyectiles.get(i);
    if (estado == 1) p.actualizar();
    p.dibujar();

    if (estado == 1) {
      if (p.verificarImpactoHeroe()) {
        heroe.recibirDano();
        listaProyectiles.remove(i);
      } 
      else if (p.pos.x < camaraX - 200 || p.pos.x > camaraX + width + 200) {
        listaProyectiles.remove(i);
      }
    }
  }

  if (estado == 1 && proximaPlataformaX < camaraX + width + 400) crearNuevaPlataforma();

  heroe.dibujar();
  popMatrix();
  // =========================================================================
  // --- FIN DEL ESPACIO DE MATRIZ DE CÁMARA (Coordenadas de Pantalla/HUD) ---
  // =========================================================================

  // HUD: MÁSCARAS ESTILO HOLLOW KNIGHT
  pushStyle();
  imageMode(CENTER);
  for (int i = 0; i < heroe.vidas; i++) {
    float mascaraX = 35 + (i * 35);
    float mascaraY = 40;
    if (heroe.invencible && estado == 1) {
      mascaraX += random(-2, 2);
      mascaraY += random(-2, 2);
    }
    image(imgMascara, mascaraX, mascaraY);
  }
  popStyle();

  // HUD: CONTADOR DE MONEDAS
  textAlign(RIGHT, BASELINE);
  textSize(24);
  fill(255, 215, 0);
  stroke(0);
  strokeWeight(4);
  text("MONEDAS: " + monedasRecolectadas, width - 20, 40);
  textAlign(LEFT, BASELINE);

  // INTERFAZ DE GAME OVER
  if (estado == 2) {
    fill(0, 0, 0, 180);
    rect(0, 0, width, height);
    fill(255, 50, 50);
    textSize(50);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 20);
    fill(255);
    textSize(20);
    text("Presiona 'R' para volver a jugar", width / 2, height / 2 + 40);
    textAlign(LEFT, BASELINE);
  }
}

void crearNuevaPlataforma() {
  float aleatorioY = random(300, 450);
  Plataforma nuevaPlat = new Plataforma(proximaPlataformaX, aleatorioY);
  listaPlataformas.add(nuevaPlat);
  if (random(100) < 60) {
    int cantidadMonedas = (int)random(2, 5);
    float espacio = nuevaPlat.ancho / (cantidadMonedas + 1);
    for (int i = 1; i <= cantidadMonedas; i++) {
      listaMonedas.add(new Moneda(nuevaPlat.pos.x + (i * espacio), nuevaPlat.pos.y - 40, imgMoneda));
    }
    // Reemplaza el bloque de selección de enemigo dentro de crearNuevaPlataforma() por este:
  } else if (random(100) < 70) {
    float tipoEnemigo = random(100);
    if (tipoEnemigo < 35) {
      listaEnemigos.add(new Enemigo(nuevaPlat, 20, imgEneFuego));
    } else if (tipoEnemigo < 70) {
      listaEnemigos.add(new EnemigoVolador(nuevaPlat, 20, imgEneFantasma));
    } else {
      listaEnemigos.add(new EnemigoDisparador(nuevaPlat, 20, imgEneSombra)); // <-- AgujaSombría
    }
  }

  proximaPlataformaX += nuevaPlat.ancho + random(100, 250);
}

void dibujarPantallaPausa() {
  // Fondo oscuro semi-transparente para oscurecer el juego congelado
  fill(0, 0, 0, 150);
  rect(0, 0, width, height);

  textAlign(CENTER, CENTER);
  textFont(fuenteMedieval);

  // Título de PAUSA con un parpadeo/brillo sutil
  float opacidadPausa = map(sin(frameCount * 0.08), -1, 1, 180, 255);
  fill(0, 0, 0, 150);
  text("JUEGO PAUSADO", width / 2 + 4, height / 4 + 4);
  fill(130, 0, 0, opacidadPausa);
  text("JUEGO PAUSADO", width / 2, height / 4);

  // Configuración de los 3 botones medievales
  float botonAncho = 240;
  float botonAlto = 50;
  float centroX = width / 2;
  float inicioY = height / 2 - 50;

  float btnReanudarY = inicioY;
  float btnReiniciarY = inicioY + 65;
  float btnMenuY = inicioY + 130;

  // Dibujamos las tres opciones con el estilo medieval existente
  dibujarBotonMedieval(centroX - (botonAncho / 2), btnReanudarY, botonAncho, botonAlto, "REANUDAR (P)");
  dibujarBotonMedieval(centroX - (botonAncho / 2), btnReiniciarY, botonAncho, botonAlto, "REINICIAR NIVEL");
  dibujarBotonMedieval(centroX - (botonAncho / 2), btnMenuY, botonAncho, botonAlto, "MENU PRINCIPAL");
}


void mousePressed() {
  if (estado == 0) {
    float botonAncho = 260;
    float botonAlto = 55;
    float centroX = width / 2;
    float btnJugarX = centroX - (botonAncho / 2);
    float btnJugarY = (height / 2) - 10;
    float btnAyudaX = centroX - (botonAncho / 2);
    float btnAyudaY = (height / 2) + 70;
    if (mouseX > btnJugarX && mouseX < btnJugarX + botonAncho && mouseY > btnJugarY && mouseY < btnJugarY + botonAlto) {
      reiniciarJuego();
    }
    if (mouseX > btnAyudaX && mouseX < btnAyudaX + botonAncho && mouseY > btnAyudaY && mouseY < btnAyudaY + botonAlto) {
      estado = 3;
    }
  } else if (estado == 3) {
    float volverX = width / 2 - 80;
    float volverY = height / 3 + 350; // <-- Cambiar a 350 para alinearlo con el dibujo
    float volverAncho = 160;
    float volverAlto = 45;

    if (mouseX > volverX && mouseX < volverX + volverAncho && mouseY > volverY && mouseY < volverY + volverAlto) {
      estado = 0;
    }
  } else if (estado == 4) {
    float botonAncho = 240;
    float botonAlto = 50;
    float centroX = width / 2;
    float inicioY = height / 2 - 50;

    float btnReanudarY = inicioY;
    float btnReiniciarY = inicioY + 65;
    float btnMenuY = inicioY + 130;

    if (mouseX > centroX - (botonAncho / 2) && mouseX < centroX + (botonAncho / 2) && mouseY > btnReanudarY && mouseY < btnReanudarY + botonAlto) {
      estado = 1;
    }
    if (mouseX > centroX - (botonAncho / 2) && mouseX < centroX + (botonAncho / 2) && mouseY > btnReiniciarY && mouseY < btnReiniciarY + botonAlto) {
      reiniciarJuego();
    }
    if (mouseX > centroX - (botonAncho / 2) && mouseX < centroX + (botonAncho / 2) && mouseY > btnMenuY && mouseY < btnMenuY + botonAlto) {
      estado = 0;
    }
  
  
      // Busquen la condición del clic en MENU PRINCIPAL dentro de mousePressed():
    if (mouseX > centroX - (botonAncho / 2) && mouseX < centroX + (botonAncho / 2) && mouseY > btnMenuY && mouseY < btnMenuY + botonAlto) {
      estado = 0;
      
      // NUEVO: Volver a activar la música al regresar al menú principal
      if (musicaMenu != null && !musicaMenu.isPlaying()) {
        musicaMenu.loop();
      }
    }
  }
}
