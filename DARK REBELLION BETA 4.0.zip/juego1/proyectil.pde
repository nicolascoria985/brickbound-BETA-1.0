class Proyectil {
  PVector pos, vel;
  float radio = 5;
  
  Proyectil(float x, float y, float angulo) {
    pos = new PVector(x, y);
    // Creamos la velocidad usando el ángulo exacto hacia el jugador
    vel = PVector.fromAngle(angulo);
    vel.mult(5.5); // Velocidad del proyectil
  }
  
  void actualizar() {
    pos.add(vel);
  }
  
  void dibujar() {
    pushStyle();
    noStroke();
    fill(75, 0, 130, 200); // Color morado oscuro/sombra
    ellipse(pos.x, pos.y, radio * 2, radio * 2);
    // Brillo del proyectil
    fill(148, 0, 211, 150);
    ellipse(pos.x, pos.y, radio * 1.4, radio * 1.4);
    popStyle();
  }
  
  // Verifica si el proyectil le pegó al héroe
  boolean verificarImpactoHeroe() {
    if (heroe == null) return false;
    float heroeCentroX = heroe.pos.x + (heroe.ancho / 2);
    float heroeCentroY = heroe.pos.y + (heroe.alto / 2);
    float distancia = dist(pos.x, pos.y, heroeCentroX, heroeCentroY);
    return distancia < (radio + (heroe.ancho / 2));
  }
}
