class Jugador {
  // Propiedades básicas
  PVector pos;
  PVector vel;
  float ancho, alto;
  
  
  // Propiedades de juego y vidas
  int vidas;
  boolean invencible;
  int tiempoInvencible;
  
  // Físicas pulidas
  float velocidadMaxima = 6;
  float aceleracion = 0.5;
  float friccion = 0.85;
  float impulsoSalto = -11.5;
  boolean enElSuelo;
  
  // Dirección para orientar el Sprite (1 = Derecha, -1 = Izquierda)
  int direccion = 1; 
  
  // Estados de control
  boolean teclaIzquierda = false;
  boolean teclaDerecha = false;
  
  // Propiedades de ataque
  int cooldownDisparo = 0;      
  int cadenciaDisparo = 20;     
  
  // --- NUEVAS VARIABLES DE ANIMACIÓN ---
  PImage imgIdle;
  PImage imgJump;
  PImage[] imgRun; // Arreglo para guardar los fotogramas de correr
  int totalFotogramasCorrer = 3; // Cambia este número según cuántas imágenes de correr uses
  float frameActual = 0;
  float velocidadAnimacion = 0.2; // Qué tan rápido cambian los pies al correr

  // Constructor
  Jugador(float xInicial, float yInicial) {
    pos = new PVector(xInicial, yInicial);
    vel = new PVector(0, 0);
    ancho = 55;
    alto = 75;
    enElSuelo = false;
    
    vidas = 3;
    invencible = false;
    tiempoInvencible = 0;
    
    // --- CARGA DE ANIMACIONES --- //
    imgIdle = loadImage("centinela.png");
    imgJump = loadImage("centinela_saltando.png");
    
    imgRun = new PImage[totalFotogramasCorrer];
    for (int i = 0; i < totalFotogramasCorrer; i++) {
      imgRun[i] = loadImage("centinela_corriendo.png");
    }
  }
  
  // Procesa movimiento y físicas
  void actualizar(float gravedad) {
    if (teclaIzquierda) {
      vel.x -= aceleracion;
      direccion = -1; 
    } else if (teclaDerecha) {
      vel.x += aceleracion;
      direccion = 1;  
    } else {
      vel.x *= friccion; 
    }
    
    vel.x = constrain(vel.x, -velocidadMaxima, velocidadMaxima);
    pos.x += vel.x;
    
    if (pos.x < 0) { pos.x = 0; vel.x = 0; }
    
    vel.y += gravedad;
    vel.y = constrain(vel.y, -20, 15); 
    pos.y += vel.y;
    
    if (invencible) {
      tiempoInvencible--;
      if (tiempoInvencible <= 0) {
        invencible = false;
      }
    }
    
    if (cooldownDisparo > 0) {
      cooldownDisparo--;
    }
    
    // --- ACTUALIZACIÓN DEL FOTOGRAMA DE CAMINATA ---
    if (enElSuelo && abs(vel.x) > 0.2) {
      frameActual += velocidadAnimacion;
      if (frameActual >= totalFotogramasCorrer) {
        frameActual = 0; // Reinicia el ciclo de caminata
      }
    } else {
      frameActual = 0; // Si se detiene, vuelve al primer fotograma
    }
  }
  
  // El método dibujar ahora decide de forma interna qué sprite mostrar
  // Ignoramos el PImage img del parámetro viejo para no romper tu pestaña principal
  void dibujar(PImage imgIgnorada) {
    if (invencible && frameCount % 6 < 3) {
      return; 
    }
    
    // --- SELECCIÓN INTELIGENTE DEL SPRITE ---
    PImage spriteActual = imgIdle; // Sprite por defecto
    
    if (!enElSuelo) {
      spriteActual = imgJump; // Si está en el aire, usa el de salto
    } else if (abs(vel.x) > 0.2) {
      spriteActual = imgRun[int(frameActual)]; // Si corre en el suelo, usa el índice del ciclo
    }
    
    pushMatrix();
    
    if (spriteActual != null) {
      if (direccion == -1) {
        translate(pos.x + ancho, pos.y);
        scale(-1, 1);
        image(spriteActual, 0, 0, ancho, alto);
      } else {
        translate(pos.x, pos.y);
        image(spriteActual, 0, 0, ancho, alto);
      }
    } else {
      translate(pos.x, pos.y);
      fill(220, 50, 50); 
      stroke(0);
      strokeWeight(2);
      rect(0, 0, ancho, alto, 4);
    }
    
    popMatrix();
  }
  
  void saltar() {
    if (enElSuelo) {
      vel.y = impulsoSalto;
      enElSuelo = false;
    }
  }
  
  void verificarColisionSuelo(float sueloX, float sueloY, float sueloAncho) {
    if (pos.x + ancho > sueloX && pos.x < sueloX + sueloAncho) {
      if (vel.y >= 0 && pos.y + alto >= sueloY && pos.y + alto <= sueloY + vel.y + 4) {
        pos.y = sueloY - alto; 
        vel.y = 0;
        enElSuelo = true;
      }
    }
  }
  
  void recibirDano() {
    if (!invencible) {
      vidas--;
      invencible = true;
      tiempoInvencible = 60; 
      vel.y = -6; 
    }
  }
  
  void disparar(ArrayList<Proyectil> lista) {
    if (cooldownDisparo == 0) {
      float origenX = (direccion == 1) ? (pos.x + ancho) : pos.x;
      float origenY = pos.y + (alto / 2);
      Proyectil nuevoProyectil = new Proyectil(origenX, origenY, direccion, "jugador");
      lista.add(nuevoProyectil);
      cooldownDisparo = cadenciaDisparo;
    }
  }
}
