class Proyectil {
  PVector pos;
  PVector vel;
  float radio;
  String bando; // "jugador" o "enemigo"
  color colorProyectil;

  Proyectil(float xInicial, float yInicial, float dir, String bandoOrigen) {
    pos = new PVector(xInicial, yInicial);
    vel = new PVector(0, 0);
    bando = bandoOrigen;
    radio = 6; 

    // Ajustamos la velocidad según quién dispara
    if (bando.equals("jugador")) {
      vel.x = dir * 10; 
      colorProyectil = color(255, 69, 0); // Fuego naranja para el héroe
    } else {
      vel.x = dir * 4; 
      colorProyectil = color(150, 0, 255); // Morado oscuro para los enemigos
    }
  }

  void actualizar() {
    pos.add(vel); // Movimiento optimizado vectorialmente
  }

  void dibujar() {
    pushStyle();
    noStroke();
    
    // Efecto de brillo/aura sutil
    fill(colorProyectil, 100);
    ellipse(pos.x, pos.y, radio * 2.5, radio * 2.5);
    
    // Centro del proyectil
    fill(colorProyectil);
    ellipse(pos.x, pos.y, radio * 2, radio * 2);
    
    popStyle();
  }
}
