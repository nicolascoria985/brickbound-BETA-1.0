class Enemigo {
  PVector pos;
  PVector vel;
  float radio = 40;
  PImage imgSprite;
  float limiteIzquierdo;
  float limiteDerecho;

  Enemigo(float xInicial, float yInicial, float radioInicial, float inicioPlat, float anchoPlat) {
    pos = new PVector(xInicial, yInicial);
    vel = new PVector(1.5, 0); 
    radio = radioInicial;
    limiteIzquierdo = inicioPlat + radio;
    limiteDerecho = inicioPlat + anchoPlat - radio;
    imgSprite = loadImage("fantasma de fuego.png");
  }
  
  void actualizar() {
    pos.add(vel);
    
    if (pos.x <= limiteIzquierdo) {
      pos.x = limiteIzquierdo;
      vel.x *= -1;
    }
    if (pos.x >= limiteDerecho) {
      pos.x = limiteDerecho;
      vel.x *= -1;
    }
  }
  
  void dibujar() {
    if (imgSprite != null) {
      pushStyle();
      imageMode(CORNER); 
      image(imgSprite, pos.x - radio, pos.y - radio * 2, radio * 2, radio * 2);
      popStyle();
    } else {
      fill(150, 0, 255);
      ellipse(pos.x, pos.y - radio, radio * 2, radio * 2);
    }
  }
}

class EnemigoVolador extends Enemigo {
  float anguloFlotar = 0;
  float yOriginal;

  EnemigoVolador(float xInicial, float yInicial, float radioInicial, float inicioPlat, float anchoPlat) {
    super(xInicial, yInicial - 40, radioInicial, inicioPlat, anchoPlat); 
    yOriginal = yInicial - 40;
    vel.x = 2.0; 
    imgSprite = loadImage("fantasma.png");
  }

  void actualizar() {
    super.actualizar(); 
    anguloFlotar += 0.05;
    pos.y = yOriginal + sin(anguloFlotar) * 30; 
  }

  void dibujar() {
    if (imgSprite != null) {
      pushStyle();
      imageMode(CORNER); 
      image(imgSprite, pos.x - radio, pos.y - radio * 2, radio * 2, radio * 2);
      popStyle();
    } else {
      pushStyle();
      fill(255, 0, 255);
      ellipse(pos.x, pos.y - radio, radio * 2, radio * 2);
      fill(255);
      ellipse(pos.x - radio, pos.y - radio - 5, 10, 10);
      ellipse(pos.x + radio, pos.y - radio - 5, 10, 10);
      popStyle();
    }
  }
}

class EnemigoDisparador extends Enemigo {
  int cronometroDisparo = 0;
  int tiempoEntreDisparos = 120; 

  EnemigoDisparador(float xInicial, float yInicial, float radioInicial, float inicioPlat, float anchoPlat) {
    super(xInicial, yInicial, radioInicial, inicioPlat, anchoPlat);
    vel.x = 1.0; 
    imgSprite = loadImage("agujasombria.png");
  }

  void actualizar() {
    super.actualizar();
    cronometroDisparo++;
    if (cronometroDisparo >= tiempoEntreDisparos) {
      dispararProyectil();
      cronometroDisparo = 0;
    }
  }

  void dispararProyectil() {
    float dirDisparo = (vel.x > 0) ? 1 : -1;
    float origenX = pos.x + (dirDisparo * radio);
    float origenY = pos.y - radio;
    listaProyectiles.add(new Proyectil(origenX, origenY, dirDisparo, "enemigo"));
  }

  void dibujar() {
    if (imgSprite != null) {
      pushStyle();
      imageMode(CORNER); 
      image(imgSprite, pos.x - radio, pos.y - radio * 2, radio * 2, radio * 2);
      popStyle();
    } else {
      pushStyle();
      fill(200, 50, 0);
      ellipse(pos.x, pos.y - radio, radio * 2, radio * 2);
      fill(50);
      float dirBoca = (vel.x > 0) ? 8 : -8;
      rect(pos.x + (dirBoca > 0 ? 0 : dirBoca), pos.y - radio - 4, 8, 8);
      popStyle();
    }
  }
}
