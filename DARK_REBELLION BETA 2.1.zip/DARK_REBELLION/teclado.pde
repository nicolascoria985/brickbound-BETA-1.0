void keyPressed() {
  if (estado == 0) {
    if (keyCode == ENTER || keyCode == RETURN) {
      reiniciarJuego();
    }
    return;
  }

  if (estado == 2) {
    if (key == 'r' || key == 'R') {
      reiniciarJuego();
    }
    return; 
  }

  if (keyCode == LEFT || key == 'a' || key == 'A' )  izquierda = true;
  if (keyCode == RIGHT || key == 'd'|| key == 'D' ) derecha = true;
  if (keyCode == UP || key == 'w' || key == 'W' || key == ' ') heroe.saltar();
  
  if (key == 'z' || key == 'Z') {
    heroe.disparar(listaProyectiles);
  }
}

void keyReleased() {
  if (keyCode == LEFT || key == 'a' ||key == 'A')  izquierda = false;
  if (keyCode == RIGHT || key == 'd'|| key == 'D' ) derecha = false;
}
