ArrayList<Plataforma> listaPlataformas = new ArrayList<Plataforma>(); 
ArrayList<Enemigo> listaEnemigos = new ArrayList<Enemigo>(); 
ArrayList<Proyectil> listaProyectiles = new ArrayList<Proyectil>();
ArrayList<Moneda> listaMonedas = new ArrayList<Moneda>();

float proximaPlataformaX = 400; 
Jugador heroe;
PImage imgMario, imgSprite, moneda;

float gravedad = 0.4;
float camaraX = 0; 
float anchoSuelo = 400;
float anchoNubeBucle = 300;

boolean izquierda = false, derecha = false;
int estado = 0, monedasRecolectadas = 0;
float camaraMenuNubes = 0;

PFont fuenteTitulo; // Declaración de la tipografía

void setup() {
  size(800, 600);
  imgMario = loadImage("centinela.png");
  imgSprite = loadImage("fantasma de fuego.png");
  imgSprite = loadImage("fantasma.png");
  imgSprite = loadImage("agujasombria.png");
  moneda = loadImage("puntos reales.png");
  
  // Cargamos la fuente del sistema operativa (Impact)
  fuenteTitulo = createFont("Impact", 64); 
  
  reiniciarJuego();
  estado = 0; 
}

void draw() {
  background(135, 206, 235); 
  if (estado == 0) dibujarMenuInicio();
  else dibujarJuego();
}

// NUEVA FUNCIÓN UNIFICADA: Aplica degradado, sombras y tipografía estilizada
void dibujarMenuInicio() {
  // FONDO: Reemplaza el background plano por un degradado vertical
  for (int y = 0; y < height; y++) {
    color colorArriba = color(20, 40, 80);
    color colorAbajo = color(135, 206, 235);
    float inter = map(y, 0, height, 0, 1);
    color c = lerpColor(colorArriba, colorAbajo, inter);
    stroke(c);
    line(0, y, width, y);
  }
  
  // Movimiento de nubes de fondo
  camaraMenuNubes += 0.5;
  dibujarNubesBucle(camaraMenuNubes);
  
  // Suelo verde plano
  fill(34, 139, 34);
  stroke(0);
  strokeWeight(2);
  rect(0, 500, width, 100);
  
  textAlign(CENTER, CENTER);
  
  // TITULO CON NUEVO ESTILO
  textFont(fuenteTitulo); 
  
  // Sombra del título proyectada en negro
  fill(0, 0, 0, 150);
  text("DARK REBELLION", width / 2 + 5, height / 3 + 5);
  
  // Título principal brillante amarillo/dorado
  fill(139, 0, 0); 
  text("DARK REBELLION", width / 2, height / 3);
  
  // Texto intermitente de inicio
  if (frameCount % 60 < 40) {
    fill(255);
    textSize(22);
    text("PRESIONA ENTER PARA EMPEZAR", width / 2, height / 2 + 60);
  }
  
  // Ventana de controles estilizada semi-transparente
  fill(0, 0, 0, 120); 
  stroke(255, 150);   
  rect(width / 2 - 180, height / 2 + 120, 360, 90, 15); 
  
  fill(255); 
  textSize(14);
  text("CONTROLES", width / 2, height / 2 + 135);
  fill(200);
  text("A / D o Flechas: Moverse", width / 2, height / 2 + 155);
  text("Espacio o Flecha Arriba: Saltar  |  Z: Disparar", width / 2, height / 2 + 175);
  
  textAlign(LEFT, BASELINE);
}

// FUNCIÓN AUXILIAR: Dibuja las nubes infinitas en bucle
void dibujarNubesBucle(float camaraOffset) {
  int nubeInicio = floor(camaraOffset / anchoNubeBucle);
  int nubesVisibles = ceil(width / anchoNubeBucle) + 1;
  
  pushMatrix();
  translate(-camaraOffset, 0);
  fill(255, 255, 255, 200);
  noStroke();
  for (int i = nubeInicio; i <= nubeInicio + nubesVisibles; i++) {
    float nubeX = i * anchoNubeBucle;
    ellipse(nubeX + 50,  100, 60, 50);
    ellipse(nubeX + 80,  90,  80, 60);
    ellipse(nubeX + 110, 100, 60, 50);
    ellipse(nubeX + 200, 150, 70, 45);
    ellipse(nubeX + 230, 145, 90, 55);
  }
  popMatrix();
}

void dibujarJuego() {
  if (estado == 1) {
    heroe.teclaIzquierda = izquierda;
    heroe.teclaDerecha = derecha;
    heroe.actualizar(gravedad);
   
    if (heroe.pos.x > width / 2) camaraX = heroe.pos.x - width / 2;
    if (heroe.pos.y > height + 100) heroe.vidas = 0; 
    if (heroe.vidas <= 0) estado = 2;
  } else {
    heroe.teclaIzquierda = false;
    heroe.teclaDerecha = false;
  }
  
  dibujarNubesBucle(camaraX * 0.3);
  stroke(0);
  heroe.enElSuelo = false; 
  
  int bloqueInicio = floor(camaraX / anchoSuelo);
  int bloquesVisibles = ceil(width / anchoSuelo) + 1;
  
  pushMatrix();
  translate(-camaraX, 0);
  
  fill(34, 139, 34); 
  for (int i = bloqueInicio; i <= bloqueInicio + bloquesVisibles; i++) {
    float sueloX = i * anchoSuelo;
    rect(sueloX, 500, anchoSuelo, 100);
    heroe.verificarColisionSuelo(sueloX, 500, anchoSuelo);
  }
  
  for (int i = listaPlataformas.size() - 1; i >= 0; i--) {
    Plataforma plat = listaPlataformas.get(i);
    plat.mostrar(); 
    heroe.verificarColisionSuelo(plat.pos.x, plat.pos.y, plat.ancho);
    if (estado == 1 && plat.pos.x < camaraX - 200) listaPlataformas.remove(i);
  }
  
  float marioCentroX = heroe.pos.x + (heroe.ancho / 2);
  float marioCentroY = heroe.pos.y + (heroe.alto / 2);
  float radioMario = heroe.ancho / 2;
  
  for (int i = listaEnemigos.size() - 1; i >= 0; i--) {
    Enemigo ene = listaEnemigos.get(i);
    if (estado == 1) ene.actualizar();
    ene.dibujar();
    
    if (estado == 1) {
      float distancia = dist(marioCentroX, marioCentroY, ene.pos.x, ene.pos.y);
      if (distancia < (radioMario + ene.radio)) {
        if (heroe.vel.y > 0 && (heroe.pos.y + heroe.alto) < ene.pos.y + 10) {
          listaEnemigos.remove(i); 
          heroe.vel.y = -9;         
          heroe.enElSuelo = false;
        } else {
          heroe.recibirDano(); 
        }
      } else if (ene.pos.x < camaraX - 200) {
        listaEnemigos.remove(i);
      }
    }
  }
  
  for (int i = listaProyectiles.size() - 1; i >= 0; i--) {
    Proyectil p = listaProyectiles.get(i);
    if (estado == 1) p.actualizar();
    p.dibujar();
    
    if (p.bando.equals("jugador")) {
      for (int j = listaEnemigos.size() - 1; j >= 0; j--) {
        Enemigo ene = listaEnemigos.get(j);
        if (dist(p.pos.x, p.pos.y, ene.pos.x, ene.pos.y) < (p.radio + ene.radio)) {
          listaEnemigos.remove(j);     
          listaProyectiles.remove(i);  
          break;                       
        }
      }
    } else if (p.bando.equals("enemigo") && estado == 1) {
      if (dist(p.pos.x, p.pos.y, marioCentroX, marioCentroY) < (p.radio + radioMario)) {
        heroe.recibirDano();         
        listaProyectiles.remove(i);  
        continue;                    
      }
    }
    
    if (i < listaProyectiles.size() && (p.pos.x < camaraX - 100 || p.pos.x > camaraX + width + 100)) {
      listaProyectiles.remove(i);
    }
  }

  for (int i = listaMonedas.size() - 1; i >= 0; i--) {
    Moneda m = listaMonedas.get(i);
    if (estado == 1) m.actualizar();
    m.dibujar();
    
    if (estado == 1) {
      if (dist(marioCentroX, marioCentroY, m.pos.x, m.pos.y) < (radioMario + m.radio)) {
        monedasRecolectadas++;
        listaMonedas.remove(i);
      } else if (m.pos.x < camaraX - 200) {
        listaMonedas.remove(i);
      }
    }
  }

  if (estado == 1 && proximaPlataformaX < camaraX + width + 400) crearNuevaPlataforma();
  
  heroe.dibujar(imgMario);
  popMatrix();
  
  textSize(24); fill(255); stroke(0); strokeWeight(4);
  text("VIDAS: " + (heroe.vidas < 0 ? 0 : heroe.vidas), 20, 40);
  
  textAlign(RIGHT, BASELINE); fill(255, 215, 0); 
  text("MONEDAS: " + monedasRecolectadas, width - 20, 40);
  textAlign(LEFT, BASELINE); 
  
  if (estado == 2) {
    fill(0, 0, 0, 180); rect(0, 0, width, height);
    fill(255, 50, 50); textSize(50); textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 20);
    fill(255); textSize(20);
    text("Presiona 'R' para volver a jugar", width / 2, height / 2 + 40);
    textAlign(LEFT, BASELINE); 
  }
}

void crearNuevaPlataforma() {
  float aleatorioY = random(300, 450); 
  Plataforma nuevaPlat = new Plataforma(proximaPlataformaX, aleatorioY);
  listaPlataformas.add(nuevaPlat);
  
  if (random(100) < 60) {
    int cantidadMonedas = (int)random(2, 5); 
    float espacio = nuevaPlat.ancho / (cantidadMonedas + 1);
    for (int i = 1; i <= cantidadMonedas; i++) {
      listaMonedas.add(new Moneda(nuevaPlat.pos.x + (i * espacio), nuevaPlat.pos.y - 40, moneda));
    }
  } else if (random(100) < 70) {
    float puntoMedioX = nuevaPlat.pos.x + (nuevaPlat.ancho / 2);
    float tipoEnemigo = random(100);
    
    if (tipoEnemigo < 40) {
      listaEnemigos.add(new Enemigo(puntoMedioX, nuevaPlat.pos.y, 20, nuevaPlat.pos.x, nuevaPlat.ancho));
    } else if (tipoEnemigo < 75) {
      listaEnemigos.add(new EnemigoVolador(puntoMedioX, nuevaPlat.pos.y, 20, nuevaPlat.pos.x, nuevaPlat.ancho));
    } else {
      listaEnemigos.add(new EnemigoDisparador(puntoMedioX, nuevaPlat.pos.y, 20, nuevaPlat.pos.x, nuevaPlat.ancho));
    }
  }
  proximaPlataformaX += nuevaPlat.ancho + random(100, 250);
}

void reiniciarJuego() {
  listaPlataformas.clear();
  listaEnemigos.clear();
  listaProyectiles.clear();
  listaMonedas.clear();
  
  monedasRecolectadas = 0;
  camaraX = 0;
  proximaPlataformaX = 400; 
  
  heroe = new Jugador(100, 300); 
  
  // Generamos 3 plataformas iniciales de golpe para poblar el inicio del mapa
  crearNuevaPlataforma();
  crearNuevaPlataforma();
  crearNuevaPlataforma();
  
  estado = 1; 
}
